package com.fopens.proxmox;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

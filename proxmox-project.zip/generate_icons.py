import os
from PIL import Image, ImageDraw, ImageFilter

def create_base_icon(size=1024, is_foreground=False, is_round=False):
    # Base image with RGBA
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    if not is_foreground:
        # Background: Dark Charcoal / Slate with subtle gradient or rounded square
        bg_color = (24, 24, 27, 255) # #18181b
        if is_round:
            draw.ellipse([0, 0, size, size], fill=bg_color)
        else:
            # Rounded rectangle
            radius = int(size * 0.22)
            draw.rounded_rectangle([0, 0, size, size], radius=radius, fill=bg_color)
            
        # Subtle inner glow / border
        border_color = (39, 39, 42, 255) # #27272a
        if is_round:
            draw.ellipse([2, 2, size-2, size-2], outline=border_color, width=int(size * 0.015))
        else:
            draw.rounded_rectangle([2, 2, size-2, size-2], radius=radius, outline=border_color, width=int(size * 0.015))

    # Calculate lightning polygon coordinates
    # Center scale factor
    s = size
    if is_foreground:
        # For adaptive foreground, icon sits in the safe center area (approx 66-70% of size)
        scale = 0.65
        cx, cy = s / 2, s / 2
        
        # Base polygon normalized relative to center (-0.5 to 0.5)
        # Normalized points
        raw_pts = [
            (-0.24, -0.26),  # top-left
            ( 0.24, -0.26),  # top-right
            ( 0.05, -0.02),  # right notch 1
            ( 0.36, -0.02),  # right point 2
            (-0.06,  0.34),  # bottom tip
            ( 0.03,  0.12),  # inner notch 2
            (-0.32,  0.12),  # left point 2
            (-0.11, -0.10),  # inner notch 1
            (-0.38, -0.10),  # left point 1
        ]
    else:
        scale = 0.68
        cx, cy = s / 2, s / 2
        raw_pts = [
            (-0.24, -0.26),  # top-left
            ( 0.24, -0.26),  # top-right
            ( 0.05, -0.02),  # right notch 1
            ( 0.36, -0.02),  # right point 2
            (-0.06,  0.34),  # bottom tip
            ( 0.03,  0.12),  # inner notch 2
            (-0.32,  0.12),  # left point 2
            (-0.11, -0.10),  # inner notch 1
            (-0.38, -0.10),  # left point 1
        ]

    pts = [(int(cx + x * s * scale), int(cy + y * s * scale)) for x, y in raw_pts]

    # Create supersampled mask for smooth anti-aliased gradient rendering
    scale_factor = 4
    high_res_size = size * scale_factor
    mask_img = Image.new('L', (high_res_size, high_res_size), 0)
    mask_draw = ImageDraw.Draw(mask_img)

    high_pts = [(int((cx + x * s * scale) * scale_factor), int((cy + y * s * scale) * scale_factor)) for x, y in raw_pts]
    mask_draw.polygon(high_pts, fill=255)

    # Optional subtle outer glow for lightning bolt
    glow_mask = mask_img.filter(ImageFilter.GaussianBlur(radius=int(18 * scale_factor * scale)))
    glow_colored = Image.new('RGBA', (high_res_size, high_res_size), (139, 92, 246, 120))
    glow_img = Image.new('RGBA', (high_res_size, high_res_size), (0, 0, 0, 0))
    glow_img.paste(glow_colored, (0, 0), glow_mask)

    # Gradient fill for the lightning bolt: #8B5CF6 (purple/violet) -> #6366F1 (indigo/blue) / #A855F7 (neon violet)
    grad_img = Image.new('RGBA', (high_res_size, high_res_size))
    # Draw linear gradient from top-left to bottom-right
    top_color = (124, 58, 237)    # #7C3AED (electric purple)
    mid_color = (168, 85, 247)    # #A855F7 (neon violet)
    bot_color = (99, 102, 241)    # #6366F1 (electric indigo-blue)
    
    grad_pixels = grad_img.load()
    for y in range(high_res_size):
        ratio_y = y / high_res_size
        for x in range(high_res_size):
            ratio_x = x / high_res_size
            ratio = (ratio_x * 0.4 + ratio_y * 0.6)
            if ratio < 0.5:
                sub_r = ratio / 0.5
                r = int(top_color[0] + sub_r * (mid_color[0] - top_color[0]))
                g = int(top_color[1] + sub_r * (mid_color[1] - top_color[1]))
                b = int(top_color[2] + sub_r * (mid_color[2] - top_color[2]))
            else:
                sub_r = (ratio - 0.5) / 0.5
                r = int(mid_color[0] + sub_r * (bot_color[0] - mid_color[0]))
                g = int(mid_color[1] + sub_r * (bot_color[1] - mid_color[1]))
                b = int(mid_color[2] + sub_r * (bot_color[2] - mid_color[2]))
            grad_pixels[x, y] = (r, g, b, 255)

    # Composite lightning on high_res
    combined_high = Image.new('RGBA', (high_res_size, high_res_size), (0, 0, 0, 0))
    combined_high.paste(glow_img, (0, 0), glow_img)
    combined_high.paste(grad_img, (0, 0), mask_img)

    # Resize back to target size with Lanczos anti-aliasing
    lightning_rendered = combined_high.resize((size, size), Image.Resampling.LANCZOS)

    # Paste onto img
    img.alpha_composite(lightning_rendered)
    return img

def main():
    res_dir = r"c:\Users\rizky\proxmox-web-management\frontend\android\app\src\main\res"
    sizes = {
        'mipmap-mdpi': (48, 108),
        'mipmap-hdpi': (72, 162),
        'mipmap-xhdpi': (96, 216),
        'mipmap-xxhdpi': (144, 324),
        'mipmap-xxxhdpi': (192, 432),
    }

    for folder, (icon_size, fg_size) in sizes.items():
        folder_path = os.path.join(res_dir, folder)
        os.makedirs(folder_path, exist_ok=True)

        # Standard icon (with rounded rect bg)
        ic_launcher = create_base_icon(icon_size, is_foreground=False, is_round=False)
        ic_launcher.save(os.path.join(folder_path, 'ic_launcher.png'), 'PNG')

        # Round icon (with round bg)
        ic_round = create_base_icon(icon_size, is_foreground=False, is_round=True)
        ic_round.save(os.path.join(folder_path, 'ic_launcher_round.png'), 'PNG')

        # Foreground for adaptive icon
        ic_fg = create_base_icon(fg_size, is_foreground=True)
        ic_fg.save(os.path.join(folder_path, 'ic_launcher_foreground.png'), 'PNG')

        print(f"Generated icons for {folder}: {icon_size}x{icon_size}, fg: {fg_size}x{fg_size}")

    # Generate 512x512 preview & favicon
    preview_512 = create_base_icon(512, is_foreground=False, is_round=False)
    preview_512.save(r"c:\Users\rizky\proxmox-web-management\frontend\public\app_icon.png", 'PNG')
    print("Generated 512x512 preview in public/app_icon.png")

if __name__ == '__main__':
    main()
